GUIA PARA CORRER O TRABALHO

1. python server.py
2. python client.py (o numero de clientes que quiser)


Descricao dos ficheiros:
server.py:		a base do servidor, estabelece ligacoes com os clientes e reencaminha as suas mensagens para as funcoes corretas

functions.py: 		complementar de server.py, esta parte trata de realizar os pedidos dos clientes

client.py:		codigo oferecido aos clientes para poderem conectar-se ao servidor e jogar

especificacao.docx:	alteracoes das mensagens da especificacao anterior

excelstora.xlsx:	excel da stora preenchido, pouco importante acho

README.txt: 		este ficheiro, descricao breve de tudo
